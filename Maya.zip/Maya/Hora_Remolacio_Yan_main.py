#Name: Daniel Miguel Hora
#Student No: 2018-
#Name: Ciazel Remolacio
#Student No: 2018 - 01717
#Name: Royce Roger F. Yan
#Student No: 2018-08902

import tkinter as tk
from tkinter import *
import time

cour = 0
intel = 0
stress = 0
report = False
midnight = False
followed = False
exam = False
gun = False
saves = 0

money = 0
resets = 0
#prints text letter by letter
def printslbl(string, label):
    for char in string:
        if label.cget('text')==string:
            break
        label.configure(text=label.cget('text') + char)
        label.update()
        time.sleep(.05)
#prints to label as a string
def prints(string, label):
    label.configure(text = string)
    label.update()
#updates scenes
def updatescene(button, label, message):
    var = IntVar()
    button.configure(command= lambda: var.set(1))
    button.update()
    button.wait_variable(var)
    label.configure(text="")
    label.update()
    button.configure(command = lambda: prints(message,label))
    button.update()
#removes conversation
def rem(lf):
    lf.pack_forget()
#displays conversation
def disp(lf):
    lf.pack(fill = X)
#waits
def waits(button):
    var = IntVar()
    button.configure(command= lambda: var.set(1))
    button.update()
    button.wait_variable(var)
#conversation
def conv(user, users, text):
    narrative.configure(text = "")
    users.configure(text = "")
    rem(cash)
    rem(maya)
    rem(wolf)
    rem(alice)
    rem(cust)
    rem(jack)
    rem(jill)
    disp(user)
    disp(users)
    nextbutton.config(command = lambda: prints(text, users))
    printslbl(text, users)
    waits(nextbutton)
#narrates
def nar(text):
    narrative.configure(text = "")
    rem(maya)
    rem(cash)
    rem(wolf)
    rem(alice)
    rem(cust)
    rem(jack)
    rem(jill)
    nextbutton.config(command = lambda: prints(text, narrative))
    printslbl(text, narrative)
    waits(nextbutton)
    
#beginning of narrative scene
def begin(text):
    rem(choice1)
    rem(choice2)
    rem(choice3)
    rem(choice4)
    narrative.configure(text = "")
    rem(maya)
    rem(cash)
    rem(wolf)
    rem(alice)
    rem(cust)
    rem(jack)
    rem(jill)
    nextbutton.config(command = lambda: prints(text, narrative))
    printslbl(text, narrative)
    waits(nextbutton)


#enters start of the game
def newgame():
    mainframe.forget()
    Scene1()
#enters load game page
def loadgame():
    print("sdssad")
#enters scene 1
def Scene1():
    #first narrate
    nextbutton.configure(command = lambda: prints(text, narrative))
    nextbutton.update()
    scene1frame.pack_propagate(0)
    scene1frame.pack()
    bgframe.pack()
    savebutton.pack(side = LEFT, fill = Y)
    nextbutton.pack(side = RIGHT, fill = Y)
    blacktextframe.pack_propagate(0)
    blacktextframe.pack(pady=(150,150))
    statsframe.pack(pady=(0,0))
    courl.pack(side = LEFT)
    intell.pack(side = LEFT)
    stressl.pack(side = LEFT)
    moneyl.pack()
    narrative.pack_propagate(0)
    narrative.pack()
    im = tk.PhotoImage(file = "pics/streets2.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "It was late at night, within the heart of the city. Vibrant neon lights and video screens illuminate the way more than the government issued streetlights. As you journey in your cab, you observe the multitude of pedestrians, almost in a trance-like state, from the tinted windows. It was lightly raining, and the light taps of the water fuses with the slow but constant beat of the radio. "
    begin(text)
    #second narate
    text = "The cab turned right. You know you are nearing your destination: a diner, not well-known, but the food has enough decency to merit your occasional return. But you are not returning there out of your own accord tonight. You are going to meet someone. A friend, you may say, but when did you ever consider anyone a friend, you wonder. Nevertheless, it seemed she also wanted to meet you."
    nar(text)
    #maya's conv 1
    maya.pack(fill = X)
    mayas.pack(side = LEFT)
    text="Maybe she needs help in our projects."
    conv(maya,mayas,text)
    #third narrative
    text = "You arrived at your destination. The street is rather silent than those on the way. There are few video screens here and there, as well as neon lights. It is an area where the development hasn't reached yet, maybe due to the low density of population, or maybe they just don't care to improve it."
    nar(text)
    im = tk.PhotoImage(file = "pics/diner.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    #fourth narrative
    text = "You entered the diner, and scanned the area to check if your classmate is already there. There are only few customers; you know them by face as they frequently visits the diner."
    nar(text)
    text += "\nExcept one\n"
    prints(text,narrative)
    waits(nextbutton)
    #fifth narrative
    text = "There is a customer at the far end of the diner. He was wearing a wolf mask. You noticed him, but quickly disregarded his presence, as you are trained to not focus too much on strangers."
    nar(text)
    #maya's convo 2
    text="She's still not here."
    conv(maya,mayas,text)
    choice1.configure(text = "Sit near the exit", command = lambda: Scene2("sit near the exit"))
    choice2.configure(text = "Sit near the window", command = lambda: Scene2("sit near the window"))
    choice1.pack()
    choice2.pack()
    mainloop()
    
#Scene2
def Scene2(ans):
    im = tk.PhotoImage(file = "pics/diner.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You decided to "+ans
    begin(text)
    #maya
    text = "Hmm. I better order something. I don't wanna be kicked out of here"
    conv(maya, mayas, text)
    #narrative
    text = "You walked towards the counter."
    nar(text)
    #cashier
    waits(nextbutton)
    text = "What will it be, hun?"
    cash.pack(fill = X)
    cashs.pack(side = LEFT)
    wolf.pack(fill = X)
    wolfs.pack(side = LEFT)
    alice.pack(fill = X)
    alices.pack(side = LEFT)
    cust.pack(fill = X)
    custs.pack(side = LEFT)
    conv(cash, cashs, text)
    #maya
    text = "Umm, I'll have... just coffee please."
    conv(maya,mayas,text)
    #cashier
    text = "Ok. We'll just serve it to your table."
    conv(cash,cashs, text)
    #maya
    text = "Thank you"
    conv(maya,mayas,text)
    #narrative
    text = "Moments later, your coffee arrived."
    nar(text)
    #cashier
    text = "Here's your coffee miss."
    conv(cash, cashs, text)
    #maya
    text = "Thank you"
    conv(maya,mayas,text)
    #narrative
    text = "You let it cool for a short moment, then you took a sip."
    nar(text)
    #maya
    text = "So bitter"
    conv(maya,mayas,text)
    #maya
    text = "I wonder what's up with Alice. She is a distant classmate from me; we do occassionally talk sometimes, but it all about academics, and only in group works. I'm not really sure why she wanted to meet with me. Mayber she wanted to know me better? Or maybe she just... needs me, like they all needed me."
    conv(maya,mayas,text)
    #narrative
    text = "Time passed, and it was almost midnight. The last remaining neon lights began to dim, and the video screens shuts down. Only the diner is open within the vicinity."
    nar(text)
    #narrative
    text = "And your classmate is still not here, nor is she answering your texts."
    nar(text)
    #maya
    text = "Maybe... the meeting is off? Then she should at least call or text. It looks like I'm waiting for nothing here."
    conv(maya,mayas,text)
    #narrative
    text = "Just as about you are finished in your coffee, the masked man stood up, and stares at you."
    nar(text)
    text+="\nAnd then began walking towards you."
    waits(nextbutton)
    prints(text, narrative)
    #maya
    text = "What the? What's up with him? Is he... is he going to approach me? No! is he a bad person? Is he going to hurt me?"
    conv(maya,mayas,text)
    #choices
    choice1.configure(text = "Walk towards the exit", command = Scene3)
    choice1.pack()
    choice2.configure(text = "Stay and try to not make eye contact", command = End1)
    choice2.pack()
    mainloop()

#Scene 3
def Scene3():
    text = "You quickly packed up your things, and hurried towards the exit. You walked for quite a while until you stopped."
    begin(text)
    im = tk.PhotoImage(file = "pics/streets2.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "There is not a single person in sight in the streets, but there was a cab at the far corner of the block. It's far that you aren't sure if the driver can notice your call."
    nar(text)
    text = "Looking back, the masked man still walks towards you, not breaking his gaze upon face."
    nar(text)
    choice1.configure(text = "Take a risk and call the cab", command = Scene3_1)
    choice1.pack()
    choice2.configure(text = "Start walking away", command = Scene3_2)
    choice2.pack()
    mainloop()
#Scene 3.1
def Scene3_1():
    im = tk.PhotoImage(file = "pics/streets2.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    global followed
    followed = True
    text = "You raised your right hand in an attempt to catch the attention of the driver. You weren't even sure if there is even a driver inside the cab , but you took the risk."
    choice3.pack()
    choice4.pack()
    begin(text)
    text = "Luckily, the risk was rewarded, as you notice the cab speeding towards you."
    nar(text)
    text = "As soon as the cab arrived, you entered swiftly. You told the driver your address, and safely got away from the diner."
    nar(text)
    text = "You arrived home safely and decided to rest."
    nar(text)
    text = "The next day..."
    nar(text)
    im = tk.PhotoImage(file = "pics/maya_apartment.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "As if only seconds has passed, your irritating phone alarm rang throughout the room, waking you instantly. "
    nar(text)
    text = "It was a nice morning. The weather's warm but the sun isn't shining much."
    nar(text)
    #maya
    text = "Ahh. So warm, and cozy. I don't want to go to school today."
    conv(maya, mayas, text)
    text = "..."
    conv(maya, mayas, text)
    text = "I wonder who that person is? What does he want with me? Why is he wearing a wolf mask?"
    conv(maya, mayas, text)
    text = "Is he a bad person?"
    conv(maya, mayas, text)
    #narrative
    text = "All these questions you though while you are going through your morning routine of preparations for your classes today."
    nar(text)
    text = "Before reaching the university, you even took the time to withdraw some funds from your student loans at the nearby bank."
    nar(text)
    global money
    money +=1300
    text = "Money Increased\n Money: "+str(money)
    moneyl.configure(text = "Money: "+str(money))
    im = tk.PhotoImage(file = "pics/Univ.png").zoom(4).subsample(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    alice.configure(text = "???")
    text = "MAYA!"
    conv(alice,alices,text)
    text = "You heard the shout coming from behind."
    nar(text)
    text = "Maya! Wait!"
    conv(alice,alices,text)
    text = "You looked back, and see your classmate, Alice, catching towards you."
    nar(text)
    alice.configure(text = "Alice")
    text = "Oh my God, Maya! I'm so so so so so sorry about last night! Something came up, and I really meant to call! But for some reason, I cannot reach your phone? Oh my gosh, are you mad? Of course you're mad!"
    conv(alice, alices, text)
    text = "Nonono, I'm not mad! (maybe a little bit). But its ok, incidents like that always happen."
    conv(maya, mayas, text)
    choice1.configure(text = "Tell about last night", command = Scene4_1)
    choice1.pack()
    choice2.configure(text = "Leave", command = Scene4_2)
    choice2.pack()
    mainloop()

#Scene 3.2
def Scene3_2():
    im = tk.PhotoImage(file = "pics/streets2.png").zoom(5).subsample(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You decided to walk downtown, where you hoped that there will be another cab, or at least a commuting vehicle or even enough people to call out for help if ever. "
    begin(text)
    text = "The walk was tedious as the night was cold. Every street you've passed lie clothed in darkness; streetlights flicker on and off and though there are occasional people and passersby, you cannot shake the feeling of anxiety."
    nar(text)
    text = "You looked back, you can no longer see the masked man following you. A wave of relief ran through your body like warmth."
    nar(text)
    text = "Steadily, you continued to walk. Your legs began to give-up, but you still went through. At last you found yourself in the town plaza. It was the part of the town that never sleeps. The streets become lively even at this time of the night, and the darkness was defeated by the neon lights and advertisement boards."
    nar(text)
    text = "From here, you called a cab, and safely took the journey home."
    nar(text)
    text = "You arrived home tired and sleepy. You are confused as to what happened tonight, but your mind and body is done for to even make sense of what happened. You just decided to rest for the night."
    nar(text)
    text = "The next day ..."
    nar(text)
    im = tk.PhotoImage(file = "pics/maya_apartment.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You had a nice, long rest from the events last night. Consequently, you are also late for your classes."
    nar(text)
    #maya
    text = "oh no! I'm late! Ah! we have a reporting today, my groupmates are going to be so mad!"
    conv(maya, mayas, text)
    #narrative
    text = "You hurriedly prepared your things, and blasted off straight to the university."
    nar(text)
    im = tk.PhotoImage(file = "pics/Univ.png").zoom(4).subsample(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    alice.configure(text = "???")
    text = "MAYA!"
    conv(alice,alices,text)
    text = "You heard the shout coming from behind."
    nar(text)
    text = "Maya! Wait!"
    conv(alice,alices,text)
    text = "You looked back, and see your classmate, Alice, catching towards you."
    nar(text)
    alice.configure(text = "Alice")
    text = "Oh my God, Maya! I'm so so so so so sorry about last night! Something came up, and I really meant to call! But for some reason, I cannot reach your phone? Oh my gosh, are you mad? Of course you're mad!"
    conv(alice, alices, text)
    text = "Nonono, I'm not mad! (maybe a little bit). But its ok, incidents like that always happen."
    conv(maya, mayas, text)
    text = "Its really ok. But I better hurry now, I'm late for my next class!"
    conv(maya, mayas, text)
    text = "I'll make it up to you, I promise!"
    conv(alice, alices, text)
    text = "You two bid your farewells, and you continued your way towards your class."
    nar(text)
    Scene5()
    mainloop()
    
def Scene4_1():
    global report
    report = True
    text = "You chose to tell Alice"
    begin(text)
    text = "Something happened last night though."
    conv(maya,mayas,text)
    text = "Oh? What happened?"
    conv(alice, alices, text)
    text = "There was a weird man in the diner. He was wearing a mask, like a wolf, I think? He stared at me for - quite a while actually, - then approached me."
    conv(maya,mayas,text)
    text = "Oh my gosh! Did he do anything to you? Are you hurt?!"
    conv(alice,alices,text)
    text = "Not really. I ran away from him. Its just weird, you know?"
    conv(maya,mayas,text)
    text = "You should report it to the police. Crimes are getting rampant in the society today. I think its better to be safe than sorry."
    conv(alice,alices, text)
    text = "You're right. Maybe later, I will report it to the police."
    conv(maya, mayas, text)
    text = "Oh! I'm getting quite late. I have to go for my classes."
    conv(maya,mayas,text)
    text = "Ok ok. I'm really sorry about last night. I'll make it up to you, I swear!"
    conv(alice, alices, text)
    text = "I'm looking forward to it then."
    conv(maya, mayas, text)
    text = "You bid your farewells, and you continued your way towards your class."
    nar(text)
    Scene5()
    mainloop()
    
def Scene4_2():
    text = "You chose to not tell and said your goodbye"
    begin(text)
    text = "Its really ok. But I better hurry now, I'm late for my next class!"
    conv(maya, mayas, text)
    text = "I'll make it up to you, I promise!"
    conv(alice, alices, text)
    text = "You two bid your farewells, and you continued your way towards your class."
    nar(text)
    Scene5()
    mainloop()
    

def Scene5():
    im = tk.PhotoImage(file = "pics/classrooom.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "The day continued like any other day. Classes here and there, surprise quizzes, problem sets, essays, exercises and the likes happened today as well."
    begin(text)
    text = "They say that college is supposed to be fairly easy if you chose your course by what your passion is."
    conv(maya,mayas, text)
    text = "..."
    conv(maya,mayas, text)
    text = "So, that was a lie."
    conv(maya,mayas,text)
    text = "Minutes, turned to hours, until at last lunch time came."
    nar(text)
    text = "You decided to go to the cafeteria."
    nar(text)
    im = tk.PhotoImage(file = "pics/cafeteria.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "In the distance on your way to a cafeteria, you notice a figure standing beside its walls. Walking forward, the figure begins to be clear. It was the masked man!"
    nar(text)
    text = "What the hell? What is he doing here?"
    conv(maya,mayas,text)
    choice1.configure(text = "Approach Him", command = lambda: Scene6(1))
    choice1.pack()
    choice2.configure(text = "Call the guard", command = lambda: Scene6(2))
    choice2.pack()
    mainloop()
    
def Scene6(num):
    global cour
    if num == 1:
        text = "You've decided to check the masked man on your own accord. That decision made you realize that you have in your power your own destiny."
        begin(text)
        cour += 1
        text = "Your Courage increased\nCourage: "+str(cour)
        nar(text)
        courl.config(text = "Courage: "+str(cour))
        text = "You tried to approach him, but as you walk closer, the figure began to walk away and fades from your sight. You walked faster towards the direction he went."
        nar(text)
        text = "... He's... gone?"
        conv(maya,mayas,text)
        text = "You went back to the cafeteria, and spent your lunch break."
        nar(text)
    else: 
        text = "You decided to look for a nearby security guard near the cafeteria"
        begin(text)
        text = "You didn't find any."
        nar(text)
        text = "Looking back, you noticed that the masked man is also gone."
        nar(text)
        text = "You went back to the cafeteria, and spent your lunch break."
        nar(text)
    global stress
    text = "After you ate, you returned to your afternoon classes. "
    nar(text)
    text = "Again, hours and hours passed by as you slogged through the classes. Some of the class gave problematic problem sets and homeworks as well as projects."
    nar(text)
    stress+=1
    text = "Stress Increased\nStress: "+str(stress)
    nar(text)
    stressl.config(text = "Stress: "+str(stress))
    text = "At last, you finished your last class for the day, but your day doesn't end there. You now have to work for your shift in a part-time job in a nearby cafe."
    nar(text)
    global report
    if report:
        report = False
        text = "Oh shoot, I still need to report the incident last night to the police. Maybe they will do something about the masked man. Ah! I will be late for my shift though. What will I do?"
        disp(maya)
        mayas.configure(text = "")
        nextbutton.config(command = lambda: prints(text,  mayas))
        printslbl(text, mayas)
        choice1.configure(text = "Report to Police", command = lambda: Police(1))
        choice1.pack()
        choice2.configure(text = "Go to your shift", command = lambda: Police(2))
        choice2.pack()
    else:
        Scene6_1()
    mainloop()
        
def Police(n):
    global stress
    global cour
    if n == 1:
        im = tk.PhotoImage(file = "pics/police_station.png").zoom(4)
        bgframe.configure(image = im)
        bgframe.forget()
        bgframe.pack()
        cour+=1
        text = "You decided to got to the police"
        begin(text)
        text = "I have to go to the police. My safety is much more important than anything else"
        conv(maya,mayas,text)
        text = "At the police station..."
        nar(text)
        text = "Umm, excuse me"
        conv(maya, mayas, text)
        cust.configure(text = "Policeman")
        text = "Hello ma'am, how can I help you?"
        conv(cust, custs, text)
        text = "I would like to report an incident last night."
        conv(maya, mayas, text)
        text = "Oh is that so? Follow me, ma'am"
        conv(cust, custs, text)
        text = "The policeman leads you to a nearby desk. He prepared some papers before entertaining your request."
        nar(text)
        text = "What's it about?"
        conv(cust, custs, text)
        text = "Well, last night..."
        conv(maya, mayas, text)
        text = "You told the police the whole story last night. You felt a little courageous that you reported the incident to the authorities.\nYour Courage Increased\nCourage: "+str(cour)
        nar(text)
        courl.config(text = "Courage: "+str(cour))
        text = "Is that all? "
        conv(cust,custs, text)
        text = "Yes, I think that's all"
        conv(maya, mayas, text)
        text = "Ma'am, be advised that since the Armistice Day approaches, local protesters, hate groups and extremists will come and create havoc. Please be careful. Regarding to your report, we will be on the look out for a wolf-masked-man in our nightly patrols. Rest assured that the police force are all mobilized during the Armistice Day to insure the safety of the people"
        conv(cust,custs,text)
        text = "Thank you"
        conv(maya,mayas,text)
        text = "You went straight to the cafe after finishing up the necessary files and papers"
        nar(text)
    else:
        text = "Stress Increased\nStress: "+str(stress)
        begin(text)
        stressl.config(text = "Stress: "+str(stress))
    Scene6_1()
    mainloop()

def Scene6_1():
    global intel
    im = tk.PhotoImage(file = "pics/cafeteria.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You decided to go to the cafe"
    nar(text)
    text = "Your shift goes from afternoon till late night, with its intensity depending on the day. Sometimes, when its a normal weekday, you would have little breaks between your shift. But today, work seems a little extra."
    nar(text)
    text = "You overheard a converstation between customers"
    nar(text)
    text = "Hey, have you heard about an internet rumor?"
    cust.config(text = "Customer 1")
    conv(cust, custs, text)
    cust.config(text = "Customer 2")
    text = "What's it about?"
    conv(cust, custs, text)
    cust.config(text = "Customer 1")
    text = "Some says that there is a website that allows you to contact a real killer!"
    conv(cust, custs, text)
    cust.config(text = "Customer 2")
    text = "Oh Shookt!"
    conv(cust, custs, text)
    cust.config(text = "Customer 1")
    text = "Yeah! you could even bargain for prices if you want someone dead!"
    conv(cust, custs, text)
    cust.config(text = "Customer 2")
    text = "That's scary!"
    conv(cust, custs, text)
    cust.config(text = "Customer 1")
    text = "I wonder how much I worth? Ahahahahah!"
    conv(cust, custs, text)
    cust.config(text = "Customer 2")
    text = "Hey don't joke like that!"
    conv(cust, custs, text)
    text = "You were called by a customer"
    nar(text)
    text = "Just a minute sir!"
    conv(maya, mayas, text)
    text = "Nightime came, and your shift ended. You went to your manager to collect your daily salary points (that's just how it works now). After collecting it, you properly signed in the log, and went directly home"
    global money
    money+=1400
    nar(text)
    text = "Money Increased\n Money: "+str(money)
    nar(text)
    moneyl.configure(text = "Money: "+str(money))
    #change bg
    im = tk.PhotoImage(file = "pics/maya_apartment.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "It was tiring day, you're sure of that. As soon as you reached your apartment, you threw yourself into your bed."
    nar(text)
    text = "Oh shoot! I have exams coming the day after tomorrow! I have to study!"
    conv(maya, mayas, text)
    text = "You flung yourself straight towards the desk so that you would not have a second thought about reviewing. Quite an effective strategy, really"
    nar(text)
    text = "You studied hard even though you're tired."
    nar(text)
    intel+=1
    text = "Intelligence Increased\nIntelligence: "+str(intel)
    nar(text)
    intell.config(text = "Intelligence: "+str(intel))
    text = "Hours passed, and you decided to stop reviewing. In a force of habit, you fixed your notebooks and books in preparation for your classes tomorrow. Its a failproof system that doesn't make you forget necessary things."
    nar(text)
    text = "You turned off the lights, and went to sleep."
    nar(text)
    text = "Next day ..."
    nar(text)
    text = "You opened the TV to hear some news before going to the university"
    nar(text)
    cust.config(text = "Newscaster")
    text = "Preparations for the Armistice Day are going steady with focus on the security and safety of those who will participate. The Government released a statement that this time, they will ensure that no one will be hurt at the activity and the events of the past Armistice Days will not happen again."
    conv(cust, custs, text)
    text = "On other news, a man was found -"
    conv(cust, custs, text)
    text = "You turned off the TV and prepared yourself."
    nar(text)
    text = "After your preparation, you directly went to the university and start your morning classes."
    nar(text)
    im = tk.PhotoImage(file = "pics/classrooom.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "At the history Class"
    nar(text)
    text = "Ok, so today let us talk about the first ever communication we've ever did to someone outside our solar system. Every one knows that the scientists of the old age hoped for communication even before in the 2nd millenium, but how exactly did the first response happened? It all began on the midday of July 12 -"
    cust.config(text = "Professor")
    conv(cust, custs, text)
    text = "You were listening, you really are, but up to this point, it seemed your eyes were anchored to the ground, and you feel very very drowsy."
    nar(text)
    text = "Shit"
    conv(maya,mayas,text)
    choice1.config(text = "Close your eyes, and fall asleep", command = Asleep)
    choice1.pack()
    choice2.config(text = "Stay Awake", command = awake)
    choice2.pack()
    mainloop()

def awake():
    global intel
    text = "You decided to stay awake and listen"
    begin(text)
    text = "No! I have to stay awake! I promised to myself that I will persevere more and do more!"
    conv(maya,mayas,text)
    cust.config(text = "Professor")
    text = "We are not a science class so I will spare you the details of how exactly we received the message, but what did the message contained? Think of it this way, it was a promise. A promise that they will visit us. Now - "
    conv(cust,custs,text)
    intel+=1
    text = "You finished the whole lesson, took down notes in order to fight the boredom, and therefore your knowledge increased\nIntelligence: "+str(intel)
    nar(text)
    intell.config(text = "Intelligence: "+str(intel))
    text ="You continued your morning classes towards lunch break"
    nar(text)
    lunch()
    mainloop()
    
def Asleep():
    text = "You decided to sleep"
    begin(text)
    text = "Screw it! I sure I can catch up when I study later!"
    conv(maya, mayas, text)
    text = "You said confidently as you doze off to sleep..."
    nar(text)
    im = tk.PhotoImage(file = "pics/Rooftop.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "Huh? Where am I?"
    conv(maya, mayas, text)
    text = "Why is it so dark?"
    conv(maya, mayas, text)
    text = "?!"
    conv(maya,mayas,text)
    text = "Hello, Maya"
    conv(wolf,wolfs,text)
    text = "W- what is happening?"
    conv(maya, mayas, text)
    text = "I'm sorry it has come to this"
    conv(wolf,wolfs,text)
    text = "Who are you?"
    conv(maya,mayas,text)
    text = "The wolf man dashed forward, and stabbed you with a needle like object - "
    nar(text)
    wakeup()
    mainloop()

def wakeup():
    global stress
    im = tk.PhotoImage(file = "pics/classrooom.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You woke up at the right moment the class is ending. You are sweating profusely, even though you feel very cold."
    begin(text)
    text = "After some moments, you calmed down. But the feeling of anxiety and fear remained."
    nar(text)
    stress+=1
    text = "what was that? That was scary! I'm glad that its just a dream though!"
    conv(maya,mayas,text)
    text = "Stress Increased\nStress: "+str(stress)
    nar(text)
    stressl.config(text = "Stress: "+str(stress))
    text = "You continued your morning classes and towards lunch time"
    nar(text)
    lunch()
    mainloop()
    
def lunch():
    im = tk.PhotoImage(file = "pics/cafeteria.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "It's lunch time"
    begin(text)
    text = "Hmm... Its lunch time. Rather than eating, I could use this time to study for my exams. What should I do?"
    conv(maya,mayas,text)
    choice1.config(text = "Study at the library", command = lambda: lunchtime(True))
    choice1.pack()
    choice2.config(text = "Eat Lunch", command = lambda: lunchtime(False))
    choice2.pack()
    mainloop()

def lunchtime(study):
    if study:
        global intel
        text = "You planned on going to the library"
        begin(text)
        text = "I... should probably study knowing my current standings"
        conv(maya,mayas,text)
        im = tk.PhotoImage(file = "pics/library.png").zoom(4)
        bgframe.configure(image = im)
        bgframe.forget()
        bgframe.pack()
        text = "You decided to go to the library instead and reviewed your notes as well as go through the readings again"
        nar(text)
        intel+=1
        text = "Intelligence Increased\nIntelligence: "+str(intel)
        nar(text)
        intell.config(text = "Intelligence: "+str(intel))
        afternoon(5)
    else:
        text = "You planned to eat lunch"
        begin(text)
        text = "Food is one of the most important things in this world! I have to eat for my brain to function well later!"
        conv(maya, mayas, text)
        text = "You said as you make way towards a fast food chain"
        nar(text)
        text = "FOOD CHAIN\nBUY ITEMS"
        nar(text)
        choice1.config(text = "Full meal (reduce stress to 2) - P100", command = lambda: afternoon(2))
        choice2.config(text = "Desert only (reduce stress to 3) - P150", command = lambda: afternoon(3))
        choice3.config(text = "Light Snack only (reduce stress to 1) - P50", command = lambda: afternoon(1))
        choice4.config(text = "Ohh. I'm not hungry", command = lambda: afternoon(4))
        choice1.pack()
        choice2.pack()
        choice3.pack()
        choice4.pack()
    mainloop()

def afternoon(n):
    global stress
    global money
    if n == 1:
        if money>=50:
            money-=50
            if stress >= n:
                stress-=n
            else:
                stress = 0
        text = "Stress Decreased\nStress: "+str(stress)
        begin(text)
        stressl.config(text = "Stress: "+str(stress))
        text = "Money Decreased\nMoney: "+str(money)
        nar(text)
        moneyl.configure(text = "Money: "+str(money))
        text = "Somehow, you've enjoyed the act of eating that it reduces your STRESS."
        nar(text)
    elif n == 2:
        if money>=100:
            money-=100
            if stress >= n:
                stress-=n
            else:
                stress = 0
        text = "Stress Decreased\nStress: "+str(stress)
        begin(text)
        stressl.config(text = "Stress: "+str(stress))
        text = "Money Decreased\nMoney: "+str(money)
        nar(text)
        moneyl.configure(text = "Money: "+str(money))
        text = "Somehow, you've enjoyed the act of eating that it reduces your STRESS.:"
        nar(text)
    elif n == 3:
        if money>=150:
            money-=150
            if stress >= n:
                stress-=n
            else:
                stress = 0
        text = "Stress Decreased\nStress: "+str(stress)
        begin(text)
        stressl.config(text = "Stress: "+str(stress))
        text = "Money Decreased\nMoney: "+str(money)
        nar(text)
        moneyl.configure(text = "Money: "+str(money))
        text = "Somehow, you've enjoyed the act of eating that it reduces your STRESS."
        nar(text)
    elif n==4:
        text = "I'm not hungry anyways..."
        begin(text)
    text = "Its almost time for the next class, so you returned to the building"
    nar(text)
    im = tk.PhotoImage(file = "pics/classroom_afternoon.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "At a Social Studies class..."
    nar(text)
    text = "That begs the question, could the First Extermination really be stopped if Gen. Balake understood what it meant for the humans? See, here's the thing -"
    cust.config(text = "Professor")
    conv(cust, custs, text)
    text = "Hey, Maya!"
    conv(alice,alices,text)
    text = "Hmm?"
    conv(maya,mayas,text)
    text = "Me and my friends are going out this evening, to the Town Circle. Wanna come? Come on! I promised that I would make it up to you, right?"
    conv(alice, alices, text)
    text = "Well,"
    choice1.configure(text = "Go with them", command =  go)
    choice2.configure(text = "I have to study", command = stay)
    choice1.pack()
    choice2.pack()
    mainloop()

def go():
    global report
    im = tk.PhotoImage(file = "pics/classrooom.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You decided to go"
    begin(text)
    text = "Ok Sure!"
    conv(maya, mayas, text)
    text = "OK! Meet us at the transportation terminal at 19:00 later! We'll be waiting!"
    conv(alice, alices, text)
    text = "Alice smiled at you as she went back to her friends"
    nar(text)
    report = True
    text = "Afternoon classes went away like a breeze. Its now time again for your part time work"
    nar(text)
    parttime()
    mainloop()

def stay():
    global report
    im = tk.PhotoImage(file = "pics/classroom_afternoon.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You decided to stay"
    begin(text)
    text = "I'm sorry, but I have to pass"
    conv(maya, mayas, text)
    text = "Aww, why?"
    conv(alice, alices, text)
    text = "Its exam tomorrow! I have to study or else I'll fail! Thanks for the offer though. You can still do your promise at other times"
    conv(maya, mayas, text)
    text = "That's too bad, my friends would also like to meet you, I would like to know you more! But, I guess it is exam season, ahahahaha! Don't worry, no hard feelings!"
    conv(alice,alices,text)
    text = "Alice smiled at you as she went back to her friends "
    nar(text)
    report = False
    text = "Afternoon classes went away like a breeze. Its now time again for your part time work"
    nar(text)
    parttime()
    mainloop()

def parttime():
    im = tk.PhotoImage(file = "pics/cafeteria.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You got in the cafe on time for your shift, and without rest, immediately began working"
    begin(text)
    text = "You overheard a conversation:"
    nar(text)
    cust.config(text = "Customer 1")
    text = "Hey, the Armistice Day is almost here"
    conv(cust,custs,text)
    cust.config(text = "Customer 2")
    text = "Yeah"
    conv(cust,custs,text)
    cust.config(text = "Customer 1")
    text = "My father took part in the War, you know"
    conv(cust,custs,text)
    cust.config(text = "Customer 2")
    text = "oh?"
    conv(cust,custs,text)
    cust.config(text = "Customer 1")
    text = "He died a hero."
    conv(cust,custs,text)
    cust.config(text = "Customer 2")
    text = "I'm sorry."
    conv(cust,custs,text)
    cust.config(text = "Customer 1")
    text = "That's the point of the Armistice Day isn't it? To honor those who have fought in the unwinnable War"
    conv(cust,custs,text)
    cust.config(text = "Customer 2")
    text = "I guess that's why they began to call it the Exterminations"
    conv(cust,custs,text)
    cust.config(text = "Customer 1")
    text = "Yeah, I guess"
    conv(cust,custs,text)
    text = "You were called by a customer"
    nar(text)
    text = "Just a minute Ma'am!"
    conv(maya,mayas,text)
    text = "Moments passed, and, as per routine, you took your points, properly said your farewells and -"
    nar(text)
    cust.config(text = "Manager")
    text = "Maya! Wait"
    conv(cust,custs,text)
    text = "What is it ma'am?"
    conv(maya,mayas,text)
    text = "How should I put this? One of the staff that works graveyard shift, well, he got sick and called in earlier to say that he cannot go to his shift tomorrow night, and, I know you are a student, and studying may be your number one priority but, I'm at wits end here. All I'm saying is, could you replace him?, just for tomorrow night? Please? Of course, it will have the proper points."
    conv(cust,custs,text)
    text = "Oh! uh..."
    conv(maya, mayas, text)
    choice1.config(text = "Take the job", command = take)
    choice2.config(text = "Refuse", command = refuse)
    choice1.pack()
    choice2.pack()
    mainloop()

def take():
    global midnight
    global cour
    midnight = True
    text = "You decided to take the job"
    begin(text)
    text = "Sure! It's Friday anyways and there's no exam after that. I could spare a few hours after midnight."
    conv(maya, mayas, text)
    text = "Really? My, thank you Maya! You really saved me!"
    conv(cust, custs, text)
    text = "Seeing your manager so relieved and happy somehow makes you feel that you chose the right thing."
    nar(text)
    cour+=1
    text = "Your Courage Increased\nCourage: "+str(cour)
    nar(text)
    courl.config(text = "Courage: "+str(cour))
    text = "Is that all, Ma'am?"
    conv(maya,mayas,text)
    text = "Yes, Yes! You can go now"
    conv(cust,custs,text)
    evening()

def refuse():
    global midnight
    midnight = False
    text = "You decided to reject the job"
    begin(text)
    text = "I'm sorry, but I have to refuse. My grades are, to put it simply, are going downhill, and I must take every oppurtunity to study as much as I can to salvage it."
    conv(maya,mayas, text)
    text = "Oh, is that so? Well, I guess, I did mention you are student after all. Maybe just for tomorrow night, we'll close the cafe."
    conv(cust, custs, text)
    text = "Seeing the manager's sunken expression made you feel that you've hurt the person, and somehow the feeling made its way to become one of your STRESSES."
    nar(text)
    text = "You can go now."
    conv(cust, custs, text)
    text = "Ok ma'am"
    conv(maya, mayas, text)
    evening()
    mainloop()

def evening():
    global report
    global stress
    global intel
    if report:
        im = tk.PhotoImage(file = "pics/plaza_night.png").zoom(1)
        bgframe.configure(image = im)
        bgframe.forget()
        bgframe.pack()
        text = "You found yourself at the Transportation terminal. Alice and her friends are already waiting for you."
        begin(text)
        text = "HI!!!!! I'm so happy you could join us!"
        conv(alice, alices, text)
        text = "I'm glad I could join as well."
        conv(maya, mayas, text)
        text = "So guys, are we complete? I think we are! Come, Maya!"
        conv(alice, alices, text)
        text = "Sure!"
        conv(maya, mayas, text)
        text = "(It's been a long time since I got invited in these get together. Maybe, once in a while, its ok to let my guard down.)"
        conv(maya, mayas, text)
        text = "You are having fun right now with your new acquantainces. You get to know more about Alice and her friends. Even though you have an exam tomorrow, the group made it so that you forgot about your worries for a while."
        nar(text)
        if stress>=3:
            stress-=3
        else:
            stress = 0
        text = "Your stress significantly decreased!\nStress: "+str(stress)
        nar(text)
        stressl.config(text = "Stress: "+str(stress))
        text = "You returned back home after saying goodbyes, tired, but somehow happy. After dressing into your pajamas, you immedietly fell asleep."
        nar(text)
    else:
        im = tk.PhotoImage(file = "pics/maya_apartment.png").zoom(2)
        bgframe.configure(image = im)
        bgframe.forget()
        bgframe.pack()
        text = "You found yourself back at the apartment. After dressing into comfortable clothes, you promptly began studying"
        nar(text)
        text = "You decided to study even though they are inviting you to a fun night. This dedication you felt on saving the semester took a strange turn into a formidable power in studying."
        nar(text)
        intel+=3
        text = "As such, your INTELLIGENCE drastically increased!\nIntelligence: "+str(intel)
        nar(text)
        intell.config(text = "Intelligence: "+str(intel))
        text = "You've studied enough. It's time to take a stop and rest for the night."
        nar(text)
    exam()
    mainloop()

def exam():
    im = tk.PhotoImage(file = "pics/maya_apartment.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You opened the TV again as you were preparing breakfast"
    begin(text)
    text = "Its only a day before the Armistice Day. So today, we invited a guest to share with us his thoughts regarding the Armistice Day. Good morning, Mr. Jay Quellin"
    cust.config(text = "Newscaster")
    conv(cust,custs,text)
    text = "Good morning"
    cust.config(text = "Jay")
    conv(cust,custs,text)
    text = "So, first things first, there is a rising pop culture of calling the War we remember in the Armistice Day as the First Extermination, what can you say about this?"
    cust.config(text = "Newscaster")
    conv(cust,custs,text)
    text = "well, the War did costs us thousands if not million lives all over the planet. So it is not entirely wrong to call it \"Exterminations\". But the fact remains. It is ultimately the decision of the Council, now what we call the Government, that led to where we are now! The war is but -"
    cust.config(text = "Jay")
    conv(cust,custs,text)
    text = "You turned off the TV as you finished preparing for the bath."
    nar(text)
    text = "After bathing, you picked up your things and directly went to the university and start your morning classes"
    nar(text)
    im = tk.PhotoImage(file = "pics/classrooom.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You arrived at the classroom."
    nar(text)
    text = "You can do this, Maya! This is an all or nothing exam. Fail this, and everything we've built upon fails as well! But I can do this, I know I can!"
    conv(maya, mayas, text)
    text = "You chose a comfortable position near the window. The winds calm your nerves down."
    nar(text)
    text = "The professor arrives and distributes the test tablets. You took a deep breath, and began answering."
    nar(text)
    text = "You finished the exam"
    nar(text)
    text = "Its already lunch time, since there really isn't anything to do since there are no more classes for today (its generally a half day before the Armistice Day), you decided to just indulge in eating."
    nar(text)
    examaft()
    mainloop()

def examaft():
    global intel
    global cour
    global stress
    text = "It is not until afternoon that the exam results will be posted. As every moment pass, you became increasingly anxious. You waited in the library."
    begin(text)
    im = tk.PhotoImage(file = "pics/library.png").zoom(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You notice at your peripheral view the masked man. But as quickly as you may have turned, he is already gone."
    nar(text)
    text = "Your phone made a notification noise. "
    nar(text)
    text = "This is it. The exam results are posted. There's no turning back now."
    conv(maya, mayas, text)
    text = "You opened the file sent to you and found out"
    nar(text)
    if intel>=5:
        text = "You have passed!"
        nar(text)
        text = "YESSSSS!!!! "
        conv(maya,mayas,text)
        text = "You shouted to yourself as you are not allowed to shout in the library"
        nar(text)
        text = "All those hardwork paid off! Finally, I passed the exam!"
        conv(maya, mayas, text)
        text = "You learned that by preparing for anything, you could achieve anything. This normal yet seemingly important realization were marked into your heart as COURAGE"
        nar(text)
        cour+=2
        text = "Courage Increased\nCourage: "+str(cour)
        nar(text)
        
        courl.config(text = "Courage: "+str(cour))
        exam = True
    else:
        text = "You have failed"
        nar(text)
        text = "Wh-What? No no no no this can't be!"
        conv(maya,mayas,text)
        text = "NO! I've studied hard for this! This can't be! What am I gonna do now?"
        conv(maya, mayas, text)
        text = "Failing an exam is one thing, but failing it after knowing that that is your last chance is another. The sheer amount of disappointment you felt towards yourself were branded into your heart as a remembrance of how dumb you are, and suddenly, it transformed into unsurmountable STRESS"
        nar(text)
        stress+=5
        text = "Stress Increased\nStress: "+str(stress)
        nar(text)
        stressl.config(text = "Stress: "+str(stress))
        exam = False
    outside()
    mainloop()

def outside():
    text = "You moved out from the library. "
    begin(text)
    text = "At the University grounds, you notice a group of people swarming in. You decided to take a look on what the commotion is about."
    nar(text)
    im = tk.PhotoImage(file = "pics/Univ.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "Hey, excuse me, what's happening?"
    conv(maya,mayas,text)
    text = "Hey, Maya! Hi! I think there's an ongoing protest about the Armistice Day, I think about changing the name into the First Extermination day. I don't really know."
    conv(alice,alices,text)
    text = "Sure enough, there is an ongoing protest. But you couldn't care much about what they are saying. Instead, you noticed something within that group of people."
    nar(text)
    text = "No! It can't be!"
    conv(maya,mayas,text)
    text = "The masked man was there, holding a placard and one with the protest"
    nar(text)
    text = "Why is he there? Is he a student here as well?"
    conv(maya,mayas,text)
    text = "Maya! Maya - Hey! Are you ok?"
    conv(alice,alices,text)
    text = "I don't understand. Why, everytime that I am feeling this- this-"
    conv(maya,mayas,text)
    text = "Maya HEY!"
    conv(alice,alices,text)
    text = "You blacked out. Maybe its because of the heat, or maybe your brain just couldn't handle what is going on. In any case, you woke up in the school's infirmary. Alice is there."
    nar(text)
    text = "Maya? Oh thank goodness you're awake!"
    conv(alice,alices,text)
    text = "?"
    conv(maya,mayas,text)
    text = "You blacked out in the grounds. we had to carry you all the way here!"
    conv(alice,alices,text)
    text = "Alice. Did you see it?"
    conv(maya,mayas,text)
    text = "See what?"
    conv(alice,alices,text)
    text = "A masked-man, a wolf!"
    conv(maya,mayas,text)
    text = "Yeah, there is a - OH! Is that the man that harrassed you the other night?"
    conv(alice,alices,text)
    text = "I don't think so, but it scared me."
    conv(maya,mayas,text)
    text = "There, there. Don't worry, you're safe here."
    conv(alice,alices,text)
    text = "What time is it?"
    conv(maya,mayas,text)
    text = "Its 18:00, why?"
    conv(alice,alices, text)
    text = "Oh shit! My shift!"
    conv(maya,mayas,text)
    text = "Wait you need to rest!"
    conv(alice,alices,text)
    text = "No, I think I'm good."
    conv(maya,mayas,text)
    text = "NO! you need to rest."
    conv(alice,alices,text)
    text = "I really don't think I need it anymore. I feel fine."
    conv(maya,mayas,text)
    text = "Would you change your mind?"
    conv(alice,alices,text)
    text = "I don't think so, no."
    conv(maya,mayas,text)
    text = "well, if you really must go. I will go too,"
    conv(alice,alices,text)
    text = "Thank you, Alice"
    conv(maya,mayas,text)
    text = "Don't mention it."
    conv(alice,alices,text)
    text = "You began trying to get up. You really felt fine, but as you try to get out of bed, you began feeling dizzy."
    nar(text)
    text = "After a while, you've successfully got up, got dressed, and went to the cafe."
    nar(text)
    shift()
    mainloop()

def shift():
    global midnight
    im = tk.PhotoImage(file = "pics/cafeteria.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You were a little late, which is understandable. Your movements are slow, but enough to serve multiple customers at quick notice."
    begin(text)
    text = "You overheard a conversation:"
    nar(text)
    text = "Hey, have you heard about a group of extremists that hates the Armistice day?"
    cust.config(text = "Customer 1")
    conv(cust,custs,text)
    text = "Oh yeah, I hear they hurt people with connection to the First Extermination. Heck, I think even the first communication!"
    cust.config(text = "Customer 2")
    conv(cust,custs,text)
    text = "Why can't they just accept today's society"
    cust.config(text = "Customer 1")
    conv(cust,custs,text)
    text = "You were called by your manager in order to clean a table."
    nar(text)
    text = "Its late night."
    nar(text)
    if midnight:
        text = "You remember that you made a promise to your manager that you would fill in the graveyard shift."
        nar(text)
        text = "A shame, I wanted to go home already, but I guess I already made my promise"
        conv(maya,mayas,text)
        midnights()
    else:
        text = "Your shift has already ended, but stayed a little bit just to help with the closing of the shop. It felt weird to see that a 24/7 Cafe would close down just for once due to being understaffed."
        nar(text)
        text = "After doing the cleaning, you and your colleagues went home"
        nar(text)
        home()
    mainloop()

def midnights():
    im = tk.PhotoImage(file = "pics/plaza_2.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "There really isn't much to say about the midnight shift. There is little to no customers, except for occasional insomiacs and or late night patrons. "
    nar(text)
    text = "Wow, I never thought having midnight shifts would be peaceful, Hunt."
    conv(maya,mayas,text)
    text = "Damn straight, Maya. There are no customers during midnight. I don't even know why the owner of the shop decided to be open 24/7! Oh and thank you Maya for joining me."
    cust.config(text = "Hunt")
    conv(cust,custs,text)
    text = "Don't mention it"
    conv(maya,mayas,text)
    text = "You heard the door open but didn't look who entered as you are busy wiping the mugs and glasses."
    nar(text)
    text = "Welcome sir! What would - "
    conv(maya,mayas,text)
    text = "You dropped one of the glass that instantly shattered."
    nar(text)
    text = "N-NO! GET AWAY FROM ME!"
    conv(maya,mayas,text)
    text = "Maya! What's the matter?"
    conv(cust,custs,text)
    text = "GET AWAY FROM ME!"
    conv(maya,mayas,text)
    text = "Hey, hey! You! What do you want?"
    conv(cust,custs,text)
    text = "What I want... is none of your business."
    conv(wolf,wolfs,text)
    text = "Wolf attacked Hunt with great force that he flew towards the wall."
    nar(text)
    text = "Now, where was I? Oh right, Maya. I don't believe we had the pleasure of meeting before? Oh who am I kidding, I think by now you know who I am and why I am here."
    conv(wolf,wolfs,text)
    text = "Please don't"
    conv(maya,mayas,text)
    text = "I don't like seeing my targets suffer. I will end this quick for you."
    conv(wolf,wolfs,text)
    text = "Take this!"
    conv(cust,custs,text)
    text = "Hunt threw a chair at the direction of Wolf, hitting him and in a brief period stunning him"
    nar(text)
    text = "MAYA! RUN!"
    conv(cust,custs,text)
    text = "You heeded Hunt's command and ran away"
    nar(text)
    alley()
    mainloop()
    
def alley():
    im = tk.PhotoImage(file = "pics/streets2.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You ran aimlessly. You got to the part of the city that you are really not familiar with."
    begin(text)
    choice1.config(text = "Go left", command = l)
    choice2.config(text = "Go right", command = r)
    choice1.pack()
    choice2.pack()
    mainloop()

def l():
    im = tk.PhotoImage(file = "pics/streets1.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You turned left at the corner. The roads forked again"
    begin(text)
    choice1.config(text = "Go left", command = l2)
    choice2.config(text = "Go right", command = r2)
    choice1.pack()
    choice2.pack()
    mainloop()


def l2():
    im = tk.PhotoImage(file = "pics/streets3.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You've reached a building. It looks like an apartment, but you are behind it. "
    begin(text)
    text = "You noticed a fire escape leading to one of the window. There is also a backdoor you can enter to. What would you do? "
    nar(text)
    choice1.config(text = "Fire Escape", command = fireescape)
    choice2.config(text = "Backdoor", command = backdoor)
    choice1.pack()
    choice2.pack()
    mainloop()

def fireescape():
    jack.pack(fill = X)
    jacks.pack(side = LEFT)
    jill.pack(fill = X)
    jills.pack(side = LEFT)
    text = "You decided to climb through the fire escape, entering through one of open windows. There is a couple inside the room. You asked for help."
    begin(text)
    im = tk.PhotoImage(file = "pics/jjroom.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "Please- Please help me!"
    conv(maya,mayas,text)
    text = "Wh-why? What’s the matter?"
    conv(jack,jacks,text)
    text = "Honey, what’s wrong?"
    conv(jill,jills,text)
    text = "There’s a man in mask chasing me. I had… to climb… to escape."
    conv(maya,mayas,text)
    text = "Jack looks at the window. "
    nar(text)
    text = "No one’s there. Maybe he ran away? I’ll go get some water. "
    conv(jack,jacks,text)
    text = "There, there. Its ok, you’re safe here. We will protect you."
    conv(jill,jills,text)
    text = "Here, water."
    conv(jack,jacks,text)
    text = "Your shaking hands carefully grabbed the glass of water. It’s hard to drink, your throat doesn’t seem to respond to your desired action. You drank too little water."
    nar(text)
    text = "Jill, should we call the police?"
    conv(jack,jacks,text)
    text = "Yes, yes. Would you please? I’m staying with her for a while"
    conv(jill,jills,text)
    text = "Why? What does it want with me? Why does he want to kill me?!"
    conv(maya,mayas,text)
    text = "There, there. Don’t worry. The police will take care of it. If you want, you could stay the night here, we will accompany you and take watch."
    conv(jill,jills,text)
    text = "Thank you. Thank you. "
    conv(maya,mayas,text)
    text = "You decided to stay with them for the night. You don't really have much of a choice."
    nar(text)
    text = "They don’t even know me, yet they let me in for the night."
    conv(maya,mayas,text)
    text = "You began to feel safe with them. Although still a little bit shocked, you began to calm your mind, and slowly dozed off to sleep"
    nar(text)
    nmorn()
    mainloop()

def nmorn():
    global cour
    im = tk.PhotoImage(file = "pics/jjroom.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You woke up and found Jill sleeping next to you and Jack sleeping awkwardly on a chair. "
    nar(text)
    text = "Later, Jill also wakes up"
    nar(text)
    text = "Oh Maya! You're awake. Did you have a good night rest?"
    conv(jill,jills,text)
    text = "Not the best, but I had enough."
    conv(maya,mayas,text)
    text = "Good."
    conv(jill,jills,text)
    text = "Why are you helping me?"
    conv(maya,mayas,text)
    text = "Because you needed help. That's all"
    conv(jill,jills,text)
    text=  "What if, I'm a bad person and I am tricking you?"
    conv(maya,mayas,text)
    text = "Jill stared at you intently"
    nar(text)
    text = "You don't look like one."
    conv(jill,jills,text)
    text = "Looking at them, they don't even know you, but they chose to help you makes you realize that there are still lot of good people in the society. Unknowingly, the two gave you COURAGE."
    nar(text)
    cour+=1
    text = "Courage Increased\nCourage: "+str(cour)
    nar(text)
    courl.configure(text = "Courage: "+str(cour))
    text = "Jill prepared you a hearty breakfast. "
    nar(text)
    text = "We've already contacted the police. They should be searching for that Wolf soon."
    conv(jill,jills,text)
    text = "So, what's your plan?"
    conv(jill,jills,text)
    if cour>=4:
        text = "I've decided. I have to stay. This is my home, this is the life my father built for me. There's no way I would forsake it."
        conv(maya,mayas,text)
        text = "Aren't you afraid? I mean, there's someone who wants to hurt you here, shouldn't you be running away?"
        conv(jill,jills,text)
        text = "I'm very scared, to be honest. But I have to be strong. I am getting tired of being constantly afraid of everything."
        conv(maya,mayas,text)
        text = "Then, at least you need protection."
        conv(jack,jacks,text)
        text = "What do you mean?"
        conv(jill,jills,text)
        text = "I know just the right person we can go to. Maya, come with me! Of course, I assume that you have money, right? It can be a little bit pricey"
        conv(jack,jacks,text)
        text = "What are you talking about? What protection?"
        conv(maya,mayas,text)
        text = "Guns, duh"
        conv(jack,jacks,text)
        text = "She can't have that! Where did you even got that idea?"
        conv(jill,jills,text)
        text = "Well, I was just thinking that if she's staying, might as well learn how to protect herself. I could teach her"
        conv(jack,jacks,text)
        text = "And suddenly you are the expert?"
        conv(jill,jills,text)
        text = "Dear, you have no idea what I've experienced before I met you."
        conv(jack,jacks,text)
        text = "Surely there must've been another way?"
        conv(jill,jills,text)
        text = "No, He's right. I should learn to protect myself"
        conv(maya,mayas,text)
        text = "Great! It's settled. Let's buy now, I'll just get dressed!"
        conv(jack,jacks,text)
        text = "Are you sure about this? It could be dangerous and it's illegal!"
        conv(jill,jills,text)
        text = "It doesn't necessarily mean that I will have use it. It's just a precaution"
        conv(maya,mayas,text)
        text = "Ok, if you say so."
        conv(jill,jills,text)
        text = "After Jack finished dressing, you went with him in a shop."
        nar(text)
        shop()
    else:
        text = "I think... I should go away, somewhere far from here. I think I will return to our provincial house for quite some time and hide."
        conv(maya,mayas,text)
        text = "That's exactly what you should do. "
        conv(jill,jills,text)
        text = "Yeah. I can't live my life like this."
        conv(maya,mayas,text)
        text = "Do you have enough money for your travel?"
        conv(jill,jills,text)
        text = "Somehow, I could manage. I could ask for my mom, I'm sure she will help me."
        conv(maya,mayas,text)
        text = "Do you want us to join you, at least even till the Terminal?"
        conv(jill,jills,text)
        text = "Thank you, but you've done enough."
        conv(maya,mayas,text)
        text = "You aren't COURAGEOUS enough to stay, and so you decided to go back to your mother's house."
        nar(text)
        province()
    mainloop()

def province():
    im = tk.PhotoImage(file = "pics/farm.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "The journey back to the province was short, thanks to the modern modes of transportations. But from here on out, technology becomes scarce."
    begin(text)
    text = "You arrived at your house with your mother waiting at the door. You already fill her the details on your way, so she already knows. You ran towards her and hugged her"
    nar(text)
    text = "Ma."
    conv(maya,mayas,text)
    text = "There, there. It's ok, you're safe now. He cannot reach you now."
    cust.config(text = "Mom")
    conv(cust,custs,text)
    text = "*sniff* *sniff*"
    conv(maya,mayas,text)
    text = "Come, let's go in."
    conv(cust,custs,text)
    text = "The provincial life is much more simple than the city life. You are not really poor, its a well to-do family, they are able to meet ends through farming."
    nar(text)
    text = "One day, you decided to help in the Rice farm. You saw old Donald tending to his crops"
    nar(text)
    text = "Need help, Donald?"
    conv(maya,mayas,text)
    text = "Oh! Maya! Long time no see! When did you back here?"
    cust.config(text = "Donald")
    conv(cust,custs,text)
    text = "Oh, just a few days ago. Something happened in the city, I had to come back"
    conv(maya,mayas,text)
    text = "Hmm I see I see."
    conv(cust,custs,text)
    text = "Do you need help?"
    conv(maya,mayas,text)
    text = "Ahahaha, I'm not as old as you think to ask for help!"
    conv(cust,custs,text)
    text = "Ahahahaha"
    conv(maya,mayas,text)
    text = "Say..."
    conv(cust,custs,text)
    text = "Someone came here the other day"
    conv(cust,custs,text)
    text = "Hmm? Who?"
    conv(maya,mayas,text)
    text = "I don't know his name. He was really weird, you see. He seemed to know you, he asked for your whereabouts"
    conv(cust,custs,text)
    text = "What do you mean, weird?"
    conv(maya,mayas,text)
    text = "Well, he seemed to be rich and respectable, with a suit and tie, and his words and actions are well-mannered. The thing is, he is carrying a wolf's head? Like, I think those types that you can wear?"
    conv(cust,custs,text)
    text = "??!"
    conv(maya,mayas,text)
    text = "A... Wolf... mask?"
    conv(maya,mayas,text)
    text = "Yeah exactly, a mask!"
    conv(cust,custs,text)
    text = "No. No! Then!"
    conv(maya,mayas,text)
    text = "Maya, what's the matter?"
    conv(cust,custs,text)
    text = "You felt a cold bolt run from your spine to your head. You began sweating profusely."
    nar(text)
    text = "Maya, dear? What's the matter?"
    conv(cust,custs,text)
    text = "He's here He's here He's here He's here He's here"
    conv(maya,mayas,text)
    text = "Maya! Hey!"
    conv(cust,custs,text)
    text = "..."
    nar(text)
    im = tk.PhotoImage(file = "pics/jjroom.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "Jill opened the TV to here some news."
    nar(text)
    text = "In other news, a fire engulfed a farmhouse in the Twine Province. Reports said that the fire was caused by faulty wiring due to the wires being too old. Sadly, it seemed that no one survived the fire, and its residents all perished, more on the scene, we have reporter Tim -"
    cust.config(text = "Newscaster")
    conv(cust,custs,text)
    text = "Jill! Come one we'll be late!"
    conv(jack,jacks,text)
    text = "Yeah, let me just turn off the TV!"
    conv(jill,jills,text)
    Cred()
    mainloop()
    
def shop():
    im = tk.PhotoImage(file = "pics/pastries.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You entered a pastry shop."
    begin(text)
    text = "Why here? of all places?"
    conv(jill,jills,text)
    text = "Don't worry. "
    conv(jack,jacks,text)
    text = "Umm, excuse me, umm, is the owner of the shop here?"
    conv(jack,jacks,text)
    text = "Oh? Who's asking?"
    alice.config(text = "Cashier")
    conv(alice,alices,text)
    text = "My name is Jack, and we are old friends. Could you call him for me?\nOh! And mention to him that I'll be taking my crown back"
    conv(jack,jacks,text)
    text = "?"
    conv(alice,alices,text)
    text = "The cashier went upstairs and called the owner"
    cust.config(text = "Owner")
    conv(cust,custs,text)
    text = "Sir, someone named Jack is looking for you."
    conv(alice,alices,text)
    text = "Pretend I'm not here!"
    conv(cust,custs,text)
    text = "He said that he knows you."
    conv(alice,alices,text)
    text = "Who?"
    conv(cust,custs,text)
    text = "Jack, and he said he's here to get back his crown something?"
    conv(alice,alices,text)
    text = "... Jack?"
    conv(cust,custs,text)
    text = "Bring them here"
    conv(cust,custs,text)
    text ="The cashier came back"
    nar(text)
    text = "Sir said that you come to his office."
    conv(alice,alices,text)
    text = "Thank you!"
    conv(jack,jacks,text)
    text = "You climbed upstairs, and went to his office"
    nar(text)
    text = "Jack! You mad dog! You're still alive?"
    conv(cust,custs,text)
    text = "You know me! I'm immortal bitch!"
    conv(jack,jacks,text)
    text = "Ahahahaha come here you"
    conv(cust,custs,text)
    text = "Ugh, bromance"
    conv(jill,jills,text)
    text = "It's kind of cute. I kinda miss my friends seeing them"
    conv(maya,mayas,text)
    text = "So, what brings you here?"
    conv(cust,custs,text)
    text = "I'm here for the crown"
    conv(jack,jacks,text)
    text = "Why? what are you going to use it for?"
    conv(cust,custs,text)
    text = "This lady here needs it"
    conv(jack,jacks,text)
    text = "M'lady, this is a very dangerous object. It could seriously hurt someone, why would you need it? If its due to hatred, please rethink on your actions."
    conv(cust,custs,text)
    text = "She needs it for protection. She's being constantly harrassed, especially now its the Armistice Day."
    conv(jack,jacks,text)
    text = "Oh is that so? Well bugger me backwards, wait"
    conv(maya,mayas,text)
    text = "The owner took a box. Upon opening it, you saw an old age weapon."
    nar(text)
    text = "This, dear, is a gun they used during the old age. It's ancient, I now, but it's still good. It cannot be traced back, and doesn't create much noise, unlike those plasma guns where you will be drawing unnecessary attention. Jack calls it the Crown."
    conv(cust,custs,text)
    text = "I found it when I was scavenging the beach. Mr. owner here said that he could fix it. And sure enough, it still packs a punch."
    conv(jack,jacks,text)
    text = "I need it."
    conv(maya,mayas,text)
    text = "for a price. About 2,500 points."
    conv(cust,custs,text)
    global gun
    global money
    if money >=2500:
        text = "I think I can manage."
        conv(maya,mayas,text)
        money-=2500
        nar("Money Decreased\nMoney: "+str(money))
        moneyl.configure(text = "Money: "+str(money))
        text = "You've bought the gun. Its heavy, but you could still carry it effortlessly."
        nar(text)
        global gun
        gun = True
        text = "I hope i won't use it."
        conv(maya,mayas,text)
        text = "You said your goodbyes to the owner."
        nar(text)
        text = "Are you sure you're gonna be ok?"
        conv(jill,jills,text)
        text = "yes, Thank you again for everything"
        conv(maya,mayas,text)
        text = "If there's any problem, feel free to enter through our fire escape again!"
        conv(jill,jills,text)
        text = "ahahaha you got it"
        conv(maya,mayas,text)
        text = "Jack and Jill also needs to go now. You're left alone at the plaza"
        nar(text)
        plaza()
    else:
        gun = False
        text = "I couldn't afford it"
        conv(maya,mayas,text)
        text = "You said your goodbyes to the owner."
        nar(text)
        text = "Are you sure you're gonna be ok?"
        conv(jill,jills,text)
        text = "yes, Thank you again for everything"
        conv(maya,mayas,text)
        text = "If there's any problem, feel free to enter through our fire escape again!"
        conv(jill,jills,text)
        text = "ahahaha you got it"
        conv(maya,mayas,text)
        text = "Jack and Jill also needs to go now. You're left alone at the plaza"
        nar(text)
        plaza()
    mainloop()
    
def backdoor():
    im = tk.PhotoImage(file = "pics/street_deadend.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You tried the backdoor"
    begin(text)
    text = "Anyone please help me! Open the door! Please! Help!"
    conv(maya,mayas,text)
    text = "Playtime's over"
    conv(wolf,wolfs,text)
    text = "No, Please... Don't... I could pay you... I could double it..."
    conv(maya, mayas,text)
    text = "I'm sorry. We're not that kind of organization, Maya."
    conv(wolf,wolfs,text)
    text = "Please... Don't kill me..."
    conv(maya,mayas,text)
    text = "Its just business, Maya. Nothing personal. I'm gonna make it quick."
    conv(wolf,wolfs,text)
    text = "Wolf dashes towards you, stabbed you with his weapon. You began to bleed, but for some reason, it didn't hurt. You just sat there, unable to shout or ask for help, alone in the darkness, left bleeding to die."
    nar(text)
    Cred()
    mainloop()
    

def r2():
    im = tk.PhotoImage(file = "pics/street_deadend.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You ran towards the east. You continually run..."
    begin(text)
    text = "Until you met a dead end. "
    nar(text)
    text = "Playtime's over"
    conv(wolf,wolfs,text)
    text = "No, Please... Don't... I could pay you... I could double it..."
    conv(maya, mayas,text)
    text = "I'm sorry. We're not that kind of organization, Maya."
    conv(wolf,wolfs,text)
    text = "Please... Don't kill me..."
    conv(maya,mayas,text)
    text = "Its just business, Maya. Nothing personal. I'm gonna make it quick."
    conv(wolf,wolfs,text)
    text = "Wolf dashes towards you, stabbed you with his weapon. You began to bleed, but for some reason, it didn't hurt. You just sat there, unable to shout or ask for help, alone in the darkness, left bleeding to die."
    nar(text)
    Cred()
    mainloop()

def r():
    im = tk.PhotoImage(file = "pics/street_deadend.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You ran towards the east. You continually run..."
    begin(text)
    text = "Until you met a dead end. "
    nar(text)
    text = "Playtime's over"
    conv(wolf,wolfs,text)
    text = "No, Please... Don't... I could pay you... I could double it..."
    conv(maya, mayas,text)
    text = "I'm sorry. We're not that kind of organization, Maya."
    conv(wolf,wolfs,text)
    text = "Please... Don't kill me..."
    conv(maya,mayas,text)
    text = "Its just business, Maya. Nothing personal. I'm gonna make it quick."
    conv(wolf,wolfs,text)
    text = "Wolf dashes towards you, stabbed you with his weapon. You began to bleed, but for some reason, it didn't hurt. You just sat there, unable to shout or ask for help, alone in the darkness, left bleeding to die."
    nar(text)
    Cred()
    mainloop()

def home():
    text = "I feel bad for rejecting Manager's plea. But I don't have a choice! My security is in shambles and my life's in danger. I should just stay home"
    conv(maya,mayas,text)
    text = "You went directly to your apartment"
    nar(text)
    im = tk.PhotoImage(file = "pics/maya_apartment.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    if followed:
        text = "You opened the door..."
        nar(text)
        text = "For some reason, the sensor couldn't detect you, and the lights remained dim."
        nar(text)
        text = "Damn it! Why does it have to malfunction now!"
        conv(maya,mayas,text)
        text = "You trod carefully in the hallway, searching for the light switch. Your fingers found it and tried opening it."
        nar(text)
        text = "But it does not respond"
        nar(text)
        text = "Damn! Work, you idiot!"
        conv(maya,mayas,text)
        text = "You feel a presence behind you"
        nar(text)
        text = "Who's there?!"
        conv(maya,mayas,text)
        text = "It's me"
        conv(wolf,wolfs,text)
        text = "?! How did you - "
        conv(maya,mayas,text)
        text = "You felt a sharp pain in your chest, and blood oozed from your heart. "
        nar(text)
        text = "When... did... you followed me..."
        conv(maya,mayas,text)
        text = "When you called that cab, even back at that diner. Well, its no use now."
        conv(wolf, wolfs, text)
        text = "...!"
        conv(maya, mayas, text)
        text = "Wolf finished the job"
        nar(text)
        Cred()
    else:
        text = "You opened the door..."
        nar(text)
        text = "The sensor quickly detected your presence and activated the lights."
        nar(text)
        text = "I'm so beat. I should go straight to bed."
        conv(maya,mayas,text)
        text = "Its the Armistice Day tomorrow, but the celebration begins at night. Ugh, I have to go there too..."
        conv(maya,mayas,text)
        text = "I should really rest. Oh! I have a free day tomorrow! I wonder what I should do tomorrow?"
        conv(maya,mayas,text)
        text = "You threw yourself to your bed and promptly fell asleep."
        nar(text)
        text = "The next day, in order to pamper yourself, you decided to spend some time at the plaza"
        nar(text)
        plaza()
    mainloop()

def plaza():
    im = tk.PhotoImage(file = "pics/plaza.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text= "It's your free time now. There are no more classes for the week in honor of the Armistice Day, and the Cafe will also close in accordance to what the Government dictated."
    begin(text)
    text= "But right now, the plaza is full of people busy panic buying before the shops close."
    if gun:
        text = "I have a gun, and it looks like Wolf cannot attack me in this public place. Might as well enjoy the rest of the day to destress."
        conv(maya,mayas,text)
    else:
        text = "I wonder I should do?"
        conv(maya,mayas,text)
    text = "MALL:\nBUY ITEMS:"
    nar(text)
    choice1.config(text="Desserts (reduce stress 3) P150", command = lambda: celeb(3))
    choice2.config(text = "Books (increase intelligence 2) P250", command = lambda: celeb(2))
    choice3.config(text = "Milk Tea (reduce stress to 1) P100", command= lambda: celeb(1))
    choice4.config(text = "Naaaaah. I won't buy anything", command = lambda: celeb(0))
    choice1.pack()
    choice2.pack()
    choice3.pack()
    choice4.pack()
    mainloop()

def celeb(n):
    global stress
    global money
    global intel
    if n == 1:
        if money>=100:
            money-=100
            if stress >= n:
                stress-=n
            else:
                stress = 0
            text = "Stress Decreased\nStress: "+str(stress)
            begin(text)
            stressl.config(text = "Stress: "+str(stress))
            text = "Money Decreased\nMoney: "+str(money)
            nar(text)
            moneyl.configure(text = "Money: "+str(money))
            text = "Somehow, you've enjoyed the act of eating that it reduces your STRESS."
            nar(text)
            plaza2()
        else:
            text = "You have no money for that"
            begin(text)
            plaza()
    elif n == 2:
        if money>=250:
            money-=250
            intel+=n
            text = "Intelligence Increased\nIntelligence: "+str(intel)
            begin(text)
            intell.config(text = "Intelligence: "+str(intel))
            text = "Money Decreased\nMoney: "+str(money)
            nar(text)
            moneyl.configure(text = "Money: "+str(money))
            text = "Somehow, you've enjoyed the act of reading that it increased your INTELLIGENCE."
            nar(text)
            plaza2()
        else:
            text = "You have no money for that"
            begin(text)
            plaza()
            
    elif n == 3:
        if money>=150:
            money-=150
            if stress >= n:
                stress-=n
            else:
                stress = 0
            text = "Stress Decreased\nStress: "+str(stress)
            begin(text)
            stressl.config(text = "Stress: "+str(stress))
            text = "Money Decreased\nMoney: "+str(money)
            nar(text)
            moneyl.configure(text = "Money: "+str(money))
            text = "Somehow, you've enjoyed the act of eating that it reduces your STRESS."
            nar(text)
            plaza2()
        else:
            text = "You have no money for that"
            begin(text)
            plaza()
    elif n==0:
        text = "I' don't fell buying anything anyways..."
        begin(text)
        plaza2()

def plaza2():
    text = "Night time approached. As if robots, the people in the city began walking towards the Monument. The plaza closed its doors, and you also found yourself following the crowd."
    nar(text)
    im = tk.PhotoImage(file = "pics/plaza_night.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "Ugh! So many people! I can't... breathe..."
    conv(maya,mayas,text)
    text = "You decided to stay for a while in a nearby bench, so as to let the crowd go first."
    nar(text)
    text = "I shouldn't stay too far behind, he might come and -"
    conv(maya,mayas,text)
    text = "Maya~"
    conv(wolf,wolfs,text)
    text = "You saw wolf within the crowd. The people doesn't seem to mind that a masked person is standing in the middle of the streets as they continued walking to the Monument."
    nar(text)
    bchase()
    mainloop()

def bchase():
    im = tk.PhotoImage(file = "pics/lobby.png").zoom(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "Your feet dragged you to the most familiar place aside from your home, the university."
    begin(text)
    text = "Since its the Armistice Day, it is required by the Government that everyone in the university must attend it and participate. As such, the university is silent and looks like ghost town."
    nar(text)
    text = "This also means that no one will be able to help you."
    nar(text)
    text = "You saw that Wolf is right behind you. You decided to run to your building."
    nar(text)
    choice1.config(text = "Lock the door", command = lambda: inside(True))
    choice2.config(text = "Continue Running", command = lambda: inside(False))
    choice1.pack()
    choice2.pack()
    mainloop()

locked = True
def inside(lock):
    global locked
    im = tk.PhotoImage(file = "pics/lobby.png").zoom(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    if lock:
        locked = True
        text = "As you enter, you dragged a nearby table and blocked the entrance"
        begin(text)
    else:
        locked = False
        text = "You entered the building"
        begin(text)
    choice1.config(text = "Run towards a room", command = room)
    choice2.config(text = "Run towards the stairs", command = stairs)
    choice1.pack()
    choice2.pack()
    mainloop()

def room():
    im = tk.PhotoImage(file = "pics/classroom_afternoon.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You went to a nearby classroom, and locked the door behind you."
    begin(text)
    text = "Maya. Tsk tsk tsk"
    conv(wolf,wolfs,text)
    text = "You do realized that you only trapped yourself there, don't you?"
    conv(wolf,wolfs,text)
    text = "And have you forgotten how quickly I am in toppling down doors?"
    conv(wolf,wolfs,text)
    text = "In a single strike, Wolf was able to destroy the door. He is right, the room has no more way out than where you came in. "
    nar(text)
    text = "Swiftly, Wolf dashed forward and stabbed you with his weapon. You started to bleed, but somehow you couldn't shout; you couldn't move. It stopped your movements, paralyzed your lower body, then slowly went up to your heart. You could feel your chest tightening, and you can't breathe. "
    nar(text)
    text = "As you draw your last breath, your vision fades to black."
    nar(text)
    Cred()
    mainloop()

def stairs():
    im = tk.PhotoImage(file = "pics/hallway.png").zoom(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You climbed up the stairs and reached the second floor."
    begin(text)
    text = "You were out of breath"
    nar(text)
    choice1.config(text = "Take a short breather", command = tbreak)
    choice2.config(text = "Continue running", command = run)
    choice1.pack()
    choice2.pack()
    mainloop()

breath = False
def tbreak():
    im = tk.PhotoImage(file = "pics/hallway.png").zoom(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    global breath
    breath = True
    global locked
    text = "You need to stop for a while"
    begin(text)
    if locked:
        text = "After a while, You got back on your feet and continued running"
        nar(text)
        run()
    else:
        text = "Tired, are we?"
        conv(wolf,wolfs,text)
        text = "?!"
        conv(maya,mayas,text)
        text = "You know, you should really exercise more. You're lacking in stamina, that's not good when someone is chasing you"
        conv(wolf,wolfs,text)
        text = "Swiftly, Wolf dashed forward and stabbed you with his weapon. You started to bleed, but somehow you couldn't shout; you couldn't move. It stopped your movements, paralyzed your lower body, then slowly went up to your heart. You could feel your chest tightening, and you can't breathe. "
        nar(text)
        text = "As you draw your last breath, your vision fades to black."
        nar(text)
        Cred()
    mainloop()
        
def run():
    im = tk.PhotoImage(file = "pics/hallway.png").zoom(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You continued running in the hallway"
    begin(text)
    choice1.config(text = "Enter a room", command = eroom)
    choice2.config(text = "Run towards stairs", command = rstairs)
    choice1.pack()
    choice2.pack()
    mainloop()

key = False
def eroom():
    global key
    im = tk.PhotoImage(file = "pics/faculty.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You entered the faculty room."
    begin(text)
    text = "It was quite dark, but you know the layout well to be moving freely."
    nar(text)
    text = "You notice something in one of the desk. It was a key. You know what this key opens. It was the rooftop door on the leftside of the third floor!"
    nar(text)
    text = "You got the rooftop door key"
    key = True
    nar(text)
    text = "You decided to hide"
    nar(text)
    text ="Wolf entered the room"
    nar(text)
    text = "Come out come out wherever you are. I know you're here, Maya. I could smell you."
    conv(wolf,wolfs,text)
    choice1.config(text = "Proceed slowly", command = slow)
    choice2.config(text = "Dash towards exit", command = dash)
    choice1.pack()
    choice2.pack()
    mainloop()

def slow():
    im = tk.PhotoImage(file = "pics/faculty.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You decided to move very very slow, trying not to make a sound."
    begin(text)
    text ="Found you!"
    conv(text)
    text = "Wha?!"
    conv(maya,mayas,text)
    text = "Wolf throws his weapon"
    nar(text)
    choice1.config(text = "Dodge", command = dodge)
    choice2.config(text = "Don't dodge", command = ddodge)
    choice1.pack()
    choice2.pack()
    mainloop()

def dodge():
    im = tk.PhotoImage(file = "pics/hallway.png").zoom(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "Somehow you are able to dodge the weapon."
    begin(text)
    text = "In a fluid motion, you went for the exit."
    nar(text)
    text ="You quickly ran towards the third floor"
    nar(text)
    rstairs()
    mainloop()

def ddodge():
    im = tk.PhotoImage(file = "pics/faculty.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You didn't dodge"
    begin(text)
    text = "Bull's eye"
    conv(wolf,wolfs,text)
    Cred()
    mainloop()

def dash():
    im = tk.PhotoImage(file = "pics/faculty.png")
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You dashed towards the exit"
    begin(text)
    text ="Maya, where are you?"
    conv(wolf,wolfs,text)
    text = "You waited"
    nar(text)
    text = "And waited"
    nar(text)
    text = "for the right moment to move"
    nar(text)
    text ="Oh! I think I know where you are!"
    conv(wolf,wolfs,text)
    text = "Wolf dashes towards you"
    nar(text)
    text = "But you are ready to move as well, dodging his attack. In a fluid motion, you went for the exit, and went for the third floor"
    nar(text)
    rstairs()
    mainloop()
    
def rstairs():
    global breath
    im = tk.PhotoImage(file = "pics/hallway.png").zoom(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    if breath:
        text = "You quickly run towards the 3rd floor"
        begin(text)
        choice1.config(text = "Go left", command = left)
        choice2.config(text = "Go right", command = right)
        choice1.pack()
        choice2.pack()
    else:
        text = "You ran out of stamina, and your legs stopped moving entirely. You needed to catch a breather."
        begin(text)
        text = "Tired, are we?"
        conv(wolf,wolfs,text)
        text = "?!"
        conv(maya,mayas,text)
        text = "You know, you should really exercise more. You're lacking in stamina, that's not good when someone is chasing you"
        conv(wolf,wolfs,text)
        text = "Swiftly, Wolf dashed forward and stabbed you with his weapon. You started to bleed, but somehow you couldn't shout; you couldn't move. It stopped your movements, paralyzed your lower body, then slowly went up to your heart. You could feel your chest tightening, and you can't breathe. "
        nar(text)
        text= "As you draw your last breath, your vision fades to black."
        nar(text)
        Cred()
    mainloop()
        
def left():
    global key
    im = tk.PhotoImage(file = "pics/hallway.png").zoom(4)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "you decided to go left, where you are blocked by a door. This is leads to the rooftop."
    begin(text)
    if key:
        text = "You quickly opened the door with the key you've got and run towards the rooftop"
        nar(text)
        ending()
    else:
        text = "Shit! Its locked! The key must've been in the second floor faculty room!"
        conv(maya,mayas,text)
        text = "Finally! You're trapped!"
        conv(wolf,wolfs,text)
        text = "?!"
        conv(maya,mayas,text)
        text = "Let's finish this Maya, this is getting too tedious!"
        conv(wolf,wolfs,text)
        text = "Swiftly, Wolf dashed forward and stabbed you with his weapon. You started to bleed, but somehow you couldn't shout; you couldn't move. It stopped your movements, paralyzed your lower body, then slowly went up to your heart. You could feel your chest tightening, and you can't breathe. "
        nar(text)
        text = "As you draw your last breath, your vision fades to black."
        nar(text)
        Cred()
    mainloop()

def ending():
    im = tk.PhotoImage(file = "pics/rooftop.png").zoom(3)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You decided to run towards the rooftop of the building."
    begin(text)
    text = "You have nowhere to run now, Maya"
    conv(wolf,wolfs,text)
    text = "Wolf blocked the door behind him, trapping you in the rooftop."
    nar(text)
    text = "This ends here."
    conv(wolf,wolfs,text)
    text = "Why are you doing this?"
    conv(maya,mayas,text)
    text = "My boss has a very particular reason, which I am not allowed to know."
    conv(wolf,wolfs,text)
    text = "Why me?"
    conv(maya,mayas,text)
    text = "I don't know. But she said that you were one of the most important targets and this mission must be accomplished at all cost."
    conv(wolf,wolfs,text)
    text = "Wait, I think she deserve to know, considering she survived until now."
    cash.config(text = "???")
    conv(cash,cashs,text)
    text = "A familiar voice echoed from behind of Wolf. "
    nar(text)
    text = "Wh- What?! It can't be! YOU?!"
    conv(maya,mayas,text)
    text = "Yes hun. Its me"
    cash.config(text = "Cashier")
    conv(cash,cashs,text)
    text = "The cashier from the diner slowly emerged from the shadows.The once sweet lady from the diner now stands almost unknown to you. Truly, she is gone, and what stands before you is a being of evil."
    nar(text)
    text = "Do you know what we commemorate today, Maya? Today, we commemorate the First Extermination. The First, among the many that comes next, because of that stupid War of yours!"
    conv(cash, cashs, text)
    text = "I survived those exterminations, I survived that War when I was a little kid. But my family, my friends, my loved one! They took everything from me."
    conv(cash,cashs,text)
    text = "I don't understand! What does the War has got to do with me?!"
    conv(maya,mayas,text)
    text = "You were the daughter of one of the Council members that provoked them towards war! Provoked them! They who are not from this world, They who are significantly more advance than our human civilizations! And you declared war!"
    conv(cash,cashs,text)
    text = "As a result, they've come to attack us at their full power. The Exterminations, it almost drove our species to extinction! "
    conv(cash,cashs,text)
    text = "But we won that fight!"
    conv(maya,mayas,text)
    text = "At what cost? The lives of the innocents?! "
    conv(cash,cashs,text)
    text = "Now, the real War has only begun. Everytime I see this new civilization, this one that rose from the ruins of the Old World... I hate it. It reminds me of everything that happened."
    conv(cash,cashs,text)
    text = "The War for the Rebirth of Humanity begins now!"
    conv(cash,cashs,text)
    global gun
    global cour
    global stress
    if gun:
        text = "You swiftly took your gun from your bag and pointed it at the boss."
        nar(text)
        text = "I'm not alone Maya. We are but pawns in this game now. Kill us both, and another will take place. And they will be better than us. They will know better than to underestimate you."
        conv(cash,cashs,text)
        text = "Give up now Maya, it will make things easier for you."
        conv(wolf,wolfs,text)
        if cour>stress:
            trigger()
        else:
            giveup()
    else:
        text = "You started to cry. The amount of stress took a toll on your body as you fell on the floor. You stopped moving as if you'd decided to give up."
        nar(text)
        text = "Good choice, Maya. You wouldn't even survive the next assaults"
        conv(cash,cashs,text)
        text = "Do what you must, Wolf"
        conv(cash,cashs,text)
        text = "In a swift strike, Wolf stabbed you with a needle like object."
        nar(text)
        text = "It stopped you from moving your mouth and your throat as to shout. It stopped your movements, paralyzed your lower body, then slowly went up to your heart. You could feel your chest tightening, and you can't breathe. "
        nar(text)
        text = "As you draw your last breath, your vision fades to black."
        nar(text)
        text = "I'm sorry it has come to this"
        conv(cash,cashs,text)
        Cred()
    mainloop()
    
def trigger():
    im = tk.PhotoImage(file = "pics/rooftop.png").zoom(3)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = ""
    begin(text)
    text = "Then... I will face them too. I promised, to myself, and to my new friends, that I will no longer be weak."
    conv(maya,mayas,text)
    text = "And now, I promise, that I will put an end to your plans."
    conv(maya,mayas,text)
    text = "You think you can stop it? You? Of all people?"
    conv(cash,cashs,text)
    text = "I think I can"
    conv(maya,mayas,text)
    text = "You pulled the trigger... "
    nar(text)
    text = "Twice"
    nar(text)
    text = "Both Wolf and the Boss dropped dead."
    nar(text)
    text = "Your hands are shaking. It wouldn't stop."
    nar(text)
    text = "You dropped the gun"
    nar(text)
    text = "Maya no, You promised... to... be strong..."
    conv(maya,mayas,text)
    text = "You started to cry"
    nar(text)
    text = "After a while you started to calm down."
    nar(text)
    text = "No. Its only just began"
    conv(maya,mayas,text)
    text = "I have a duty now. Now that I know... To protect them... All of them, the new civilization. To stop them... threats..."
    conv(maya,mayas,text)
    text = "You gazed among the city lights. You feel a burning passion in your heart. A some sort of heroic fire, a new sense of duty."
    nar(text)
    text = "You began walking back to the door, and then, you were gone."
    nar(text)
    Cred()
    mainloop()

def giveup():
    im = tk.PhotoImage(file = "pics/rooftop.png").zoom(3)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    global exam
    text = "You started to cry. The amount of stress took a toll on your body, and you lowered your gun."
    begin(text)
    if not exam:
        text = "You remembered that you failed the exam"
        nar(text)
    else:
        text = "You remembered all the failures that happened, all the disappointments you must've made to you and to others."
        nar(text)
    text = "Good choice, Maya. You wouldn't even survive the next assaults"
    conv(cash,cashs,text)
    text = "Do what you must, Wolf"
    conv(cash,cashs,text)
    text = "In a swift strike, Wolf stabbed you with a needle like object."
    nar(text)
    text = "It stopped you from moving your mouth and your throat as to shout. It stopped your movements, paralyzed your lower body, then slowly went up to your heart. You could feel your chest tightening, and you can't breathe. "
    nar(text)
    text = "As you draw your last breath, your vision fades to black."
    nar(text)
    text = "I'm sorry it has come to this"
    conv(cash,cashs,text)
    Cred()
    mainloop()
    
def right():
    im = tk.PhotoImage(file = "pics/street_deadend.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    text = "You decided to go rightward."
    begin(text)
    text = "A dead end!"
    nar(text)
    text = "Finally! You're trapped!"
    conv(wolf,wolfs,text)
    text = "?!"
    conv(maya,mayas,text)
    text = "Let's finish this Maya, this is getting too tedious!"
    conv(wolf,wolfs,text)
    text = "Swiftly, Wolf dashed forward and stabbed you with his weapon. You started to bleed, but somehow you couldn't shout; you couldn't move. It stopped your movements, paralyzed your lower body, then slowly went up to your heart. You could feel your chest tightening, and you can't breathe. "
    nar(text)
    text = "As you draw your last breath, your vision fades to black."
    nar(text)
    Cred()
    mainloop()


#BadEnd 1
def End1():
    im = tk.PhotoImage(file = "pics/diner.png").zoom(2)
    bgframe.configure(image = im)
    bgframe.forget()
    bgframe.pack()
    #narrative
    rem(choice1)
    rem(choice2)
    text = "You decided to bow down your head as to not notice the guy."
    narrative.configure(text = "")
    rem(maya)
    rem(cash)
    rem(wolf)
    nextbutton.config(command = lambda: prints(text, narrative))
    printslbl(text, narrative)
    #maya
    waits(nextbutton)
    text="Please, don't come closer"
    conv(maya, mayas, text)
    #narrative
    text = "You heard him whisper as he passed you."
    nar(text)
    #wolf
    waits(nextbutton)
    text = "Nothing personal. You were just my target, nothing more, nothing less."
    conv(wolf, wolfs, text)
    #maya
    waits(nextbutton)
    text = "Wha----"
    conv(maya,mayas, text)
    #narrative
    text = "Quickly, he injected you with something, and nonchalantly continued walking towards the exit. It stopped you from moving your mouth and your throat as to shout. It stopped your movements, paralyzed your lower body, then slowly went up to your heart. You could feel your chest tightening, and you can't breathe. "
    nar(text)
    text = "As you draw your last breath, your vision fades to black."
    nar(text)
    text = "\"Somebody call an ambulance!\""
    nar(text)
    Cred()
    mainloop()

#Credits
def Cred():
    text = "Authors:\nRemolacio, Ciazel\nHora, Daniel Miguel\nRoyce Roger Yan"
    nar(text)
    text = "Sources:\nhttps://giphy.com/gifs/sherlock-pixel-art-lucile-patron-Azo6yw6R0TzGw\nhttps://www.pinterest.ph/pin/403142604123080230/\nhttps://www.deviantart.com/noaqh/art/Coffee-shop-663241874"
    nar(text)
    text = "Sources:\nhttp://photobucket.com/gallery/http://s1261.photobucket.com/user/EvilBorisDX/media/CortoMarin.png.html\nhttps://boingboing.net/2015/09/17/kirokaze-pixel-gif.html\n"
    nar(text)
    text = "Sources:\nhttps://www.deviantart.com/norma2d/art/Cyberpunk-room-755716454\nhttps://gfycat.com/gifs/search/dekitate+high+school\n"
    nar(text)
    text = "Sources:\nhttps://weheartit.com/entry/252574397\nhttp://www.tokkoro.com/2984398-pixels-library-ladders-pixel-art.html\n"
    nar(text)
    text = "Sources:\nhttp://pixeljoint.com/pixelart/17130.htm\nhttps://imgur.com/gallery/N47HTkW\nhttps://pixeljeff1995.artstation.com/projects/eYL3b\n"
    nar(text)
    text = "Sources:\nhttp://6502b.com/Making_pixel_art_for_In_The_Shadows.html\nhttps://www.youtube.com/watch?v=6Ezt8nNrJpQ\nhttps://www.deviantart.com/trenico/art/Police-Station-425609134"
    nar(text)
    savebutton.forget()
    nextbutton.config(text = "Play Again")
    waits(nextbutton)
    scene1frame.forget()
    nextbutton.config(text = "Next")
    nextbutton.forget()
    savebutton.forget()
    narrative.config(text="")
    narrative.forget()
    mainframe.pack()
    mainloop()
    
master = Tk()
master.title("Maya")
master.geometry("1000x800")
mainframe = Frame(master, height = 800, width = 1000, background = "#000", padx = 30, pady = 30)
mainframe.pack_propagate(0)
mainframe.pack()
titleframe = Frame(mainframe, height = 500, width = 800, background= "#000")
titleframe.pack()
img = tk.PhotoImage(file = "pics/title.png").zoom(5).subsample(4)
titlelabel = Label(titleframe, height = 500, width =  800, image = img, bg= "#000")
titlelabel.pack()
newgamebutton = Button(mainframe, text = "New Game", command = newgame, height = 3, width = 60, fg = "#fff", bg = "#0f0f0f", activebackground = "#0f0f0f", activeforeground = "#fff", font = ("Arial", 15))
newgamebutton.pack()
loadgamebutton = Button(mainframe, text = "Load Game", command = loadgame, height = 3, width = 60, fg = "#fff", bg = "#0f0f0f", activebackground = "#0f0f0f", activeforeground = "#fff", font = ("Arial", 15))
loadgamebutton.pack()
scene1frame = Frame(master, height = 800, width = 1000, background = "#000", padx = 30, pady= 30)
im = tk.PhotoImage(file = "pics/streets2.png").subsample(4).zoom(5)
bgframe = Label(scene1frame, height = 730, width = 940, background = "#000",image = im)
blacktextframe = Frame(bgframe, height =730, width = 940, background = "#000")
nextbutton = Button(blacktextframe, text = "Next", bg = "#000", fg = "#FFF", activebackground = "#000", activeforeground = "#FFF", font = ("Arial", 10))
savebutton = Button(blacktextframe, text = "Save", bg = "#000", fg = "#fff", activebackground = "#000", activeforeground = "#FFF", font = ("Arial", 10))
narrative = Label(blacktextframe, text = "", height = 9, width = 900, foreground = "#FFF", bg = "#000", font = ("Chiller", 20), wraplength=800)
maya = LabelFrame(blacktextframe, text = "Maya", fg = "#FFF", bg = "#0f0f0f", font = ("Arial", 10))
mayas = Label(maya, text="", fg = "#FFF", bg = "#0f0f0f", justify = LEFT, wraplength=800, font = ("Arial", 10))
cash = LabelFrame(blacktextframe, text = "Cashier", fg = "#FFF", bg = "#0f0f0f", font = ("Arial", 10))
cashs = Label(cash, text="", fg = "#FFF", bg = "#0f0f0f", justify = LEFT, wraplength=800, font = ("Arial", 10))
wolf = LabelFrame(blacktextframe, text = "Wolf", fg = "#FFF", bg = "#0f0f0f", font = ("Arial", 10))
wolfs = Label(wolf, text="", fg = "#FFF", bg = "#0f0f0f", justify = LEFT, wraplength=800, font = ("Arial", 10))
alice = LabelFrame(blacktextframe, text = "Alice", fg = "#FFF", bg = "#0f0f0f", font = ("Arial", 10))
alices = Label(alice, text="", fg = "#FFF", bg = "#0f0f0f", justify = LEFT, wraplength=800, font = ("Arial", 10))
jack = LabelFrame(blacktextframe, text = "Jack", fg = "#FFF", bg = "#0f0f0f", font = ("Arial", 10))
jacks = Label(jack, text="", fg = "#FFF", bg = "#0f0f0f", justify = LEFT, wraplength=800, font = ("Arial", 10))
jill = LabelFrame(blacktextframe, text = "Jill", fg = "#FFF", bg = "#0f0f0f", font = ("Arial", 10))
jills = Label(jill, text="", fg = "#FFF", bg = "#0f0f0f", justify = LEFT, wraplength=800, font = ("Arial", 10))
cust = LabelFrame(blacktextframe, text = "Customer 1", fg = "#FFF", bg = "#0f0f0f", font = ("Arial", 10))
custs = Label(cust, text="", fg = "#FFF", bg = "#0f0f0f", justify = LEFT, wraplength=800, font = ("Arial", 10))
choice1 = Button(blacktextframe, text = "Sit near the window", command = lambda: Scene2("sit near the window"), fg = "#fff", bg = "#0f0f0f", activebackground = "#0f0f0f", activeforeground = "#fff", font = ("Arial", 10))
choice2 = Button(blacktextframe, text = "Sit near the window" ,command = lambda: Scene2("sit near the window"), fg = "#fff", bg = "#0f0f0f", activebackground = "#0f0f0f", activeforeground = "#fff", font = ("Arial", 10))
choice3 = Button(blacktextframe, text = "Sit near the window" ,command = lambda: Scene2("sit near the window"), fg = "#fff", bg = "#0f0f0f", activebackground = "#0f0f0f", activeforeground = "#fff", font = ("Arial", 10))
choice4 = Button(blacktextframe, text = "Sit near the window" ,command = lambda: Scene2("sit near the window"), fg = "#fff", bg = "#0f0f0f", activebackground = "#0f0f0f", activeforeground = "#fff", font = ("Arial", 10))
statsframe = Frame(blacktextframe, height = 200, width = 800, bg = "#111")
courl = Label(statsframe, text= "Courage: 0", fg = "#FFF", bg = "#111", padx = 60, font = ("Arial", 10))
intell = Label(statsframe, text= "Intelligence: 0", fg = "#FFF", bg = "#111", padx = 60, font = ("Arial", 10))
stressl = Label(statsframe, text= "Stress: 0", fg = "#FFF", bg = "#111", padx = 60, font = ("Arial", 10))
moneyl = Label(statsframe, text= "Money: 0", fg = "#FFF", bg = "#111", padx = 60, font = ("Arial", 10))
